import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estimate-story',
  templateUrl: './estimate-story.component.html',
  styleUrls: ['./estimate-story.component.css']
})
export class EstimateStoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
