import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageCompComponent } from './home-page-comp/home-page-comp.component';
//import { SecondComponent } from './second/second.component';


const routes: Routes = [
  { path: 'home', component: HomePageCompComponent },
  //{ path: 'second-component', component: SecondComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
