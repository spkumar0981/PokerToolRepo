import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-input-estimates',
  templateUrl: './input-estimates.component.html',
  styleUrls: ['./input-estimates.component.css']
})
export class InputEstimatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
